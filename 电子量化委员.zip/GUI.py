import main
import PySimpleGUI as sg
from dingtalkchatbot.chatbot import DingtalkChatbot, ActionCard, CardItem
sg.theme('Default1')   # 设置当前主题
# 界面布局，将会按照列表顺序从上往下依次排列，二级列表中，从左往右依此排列
layout = [  #[sg.Text('积分表路径:'), sg.InputText('')],
            [sg.Text('钉钉机器人webhook地址：'),sg.InputText()],
            [sg.Text('钉钉机器人加签密钥：'),sg.InputText()],
            [sg.Text('计算内容：'),sg.Combo (['自动      ','每组最高分','每组最低分','全班最高分','全班最低分'])],
            [sg.Button('Ok'), sg.Button('Cancel')] ]
# 创造窗口
window = sg.Window('积分系统', layout)
# 事件循环并获取输入值
while True:
    event, values = window.read()
    if event in (None, 'Cancel'):   # 如果用户关闭窗口或点击`Cancel`
        break
    print('You entered ', values[0],values[1])
    xiaoding = DingtalkChatbot(values[0], secret=values[1])
    if values[2]=='每组最高分':
        Max=main.group_sort(main.group_def(main.people()),False)
        print(Max[0]+1,'组分数最高',Max[1],'分')
        body='### 今日分数简报,\n'
        '####今日', Max[0]+1, '组分数最高，高达', Max[1], '分'
        xiaoding.send_markdown(title='今日分数简报', text=body)
    if values[2]=='每组最低分':
        Min=main.group_sort(main.group_def(main.people()),True)
        print(Min[0]+1,'组分数最高',Min[1],'分')
        body = '### 今日分数简报,\n'
        '####今日', Max[0], '组分数最低，低至', Max[1], '分'
        xiaoding.send_markdown(title='今日分数简报',text=body)
window.close()


